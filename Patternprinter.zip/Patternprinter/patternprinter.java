package pmain;

import java.util.*;
import p1.Rectangle;
import p2.Square;
import p3.hollowRect;
import p4.hollowSq;
import p5.halfpyramid;
import p6.halfpyinverted;
import p7.invertedpyrotated;
import p8.halfpyrotated;
import p9.FloydTriangle;
import p10.ZeroOneTriangle;
import p11.Butterfly;
import p12.SolidRhombus;
import p13.NumPyramid;
import p14.PalindromicTri;
import p15.Diamond;

public class patternprinter 
{
    int i,j,k,l;
    public static void main(String args[]) 
    {

        System.out.println("\n******** Welcome to Pattern Printer *********\n ");
        System.out.println("1.Beginner ");
        System.out.println("2.Intermediate ");
        System.out.println("3.Advance ");

        System.out.println("Choose Difficulty level from above:");
        Scanner scan = new Scanner(System.in);
        int i = scan.nextInt();

        switch (i) 
        {
            case 1:
                System.out.println("\n1.Rectangle\n2.Square\n3.Hollow Rectangle\n4.Hollow Sqaure\n5.Half Pyramid\n6.Inverted Half Pyramid\n");
                System.out.println("Enter Your Choice :");
                Scanner scan1 = new Scanner(System.in);
                int j = scan1.nextInt();
                switch(j)
                {
                    case 1:
                    Rectangle a=new Rectangle();
                    a.printRect();
                    break;
                    
                    case 2:
                    Square b=new Square();
                    b.printSq();
                    break;

                    case 3:
                    hollowRect c=new hollowRect();
                    c.printHollowRect();
                    break;

                    case 4:
                    hollowSq d=new hollowSq();
                    d.printHollowSq();
                    break;

                    case 5:
                    halfpyramid e=new halfpyramid();
                    e.printHalfpyramid();
                    break;

                    case 6:
                    halfpyinverted  f=new halfpyinverted();
                    f.printHalfpyinverted();
                    break;

                    default:
                    System.out.println("Incorrect choice");
                    break;

                }
                break;


            case 2:
                System.out.println("\n1.Half Pyramid Rotated by 180 Degree\n2.Inverted Half Pyramid Rotated by 180 Degree\n3.Floyd's Triangle\n4.Zero-One Triangle\n");
                System.out.println("Enter Your Choice :");
                Scanner scan2 = new Scanner(System.in);
                int k = scan2.nextInt();
                switch(k)
                {
                    case 1:
                    halfpyrotated p= new halfpyrotated();
                    p.printHalfpyramidrot();
                    break;
                    
                    case 2:
                    invertedpyrotated q=new invertedpyrotated();
                    q.printinvertpyrot();
                    break;

                    case 3:
                    FloydTriangle r=new FloydTriangle();
                    r.printfloydTri();
                    break;

                    case 4:
                    ZeroOneTriangle  s=new ZeroOneTriangle();
                    s.printZeroOneTri();
                    break;

                    default:
                    System.out.println("Incorrect choice");
                    break;

                }
                break;


            case 3:
                System.out.println("\n1.Butterfy Pattern\n2.Solid Rhombus\n3.Number Pyramid\n4.Palindromic Pyramid\n5.Diamond Pattern\n");
                System.out.println("Enter Your Choice :");
                Scanner scan3 = new Scanner(System.in);
                int l = scan3.nextInt();
                switch(l)
                {
                    case 1:
                    Butterfly x=new Butterfly();
                    x.printButterfly();
                    break;
                    
                    case 2:
                    SolidRhombus y=new SolidRhombus();
                    y.printSolidRhom();
                    break;

                    case 3:
                    NumPyramid z=new NumPyramid();
                    z.printNumPy();
                    break;

                    case 4:
                    PalindromicTri u=new PalindromicTri();
                    u.printPalinPy();
                    break;

                    case 5:
                    Diamond v=new Diamond();
                    v.printDiamond();
                    break;

                    default:
                    System.out.println("Incorrect choice");
                    break;

                }
                break;
            
            default:
            System.out.println("Incorrect choice");
            break;
        }
    }
}
