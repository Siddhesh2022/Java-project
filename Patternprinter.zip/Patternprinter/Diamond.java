package p15;

import java.util.*;

public class Diamond
{
    int a,i,j,k;
    public void printDiamond() 
    {
        System.out.println("Enter the no of Rows : ");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();

        System.out.println();
        for(int i=1;i<=a;i++)
        {
            for(int j=1;j<=a-i;j++)
            {
                System.out.print(" ");
            }
            for(int j=1;j<=2*i-1;j++)
            {
                System.out.print("*");
            }
            System.out.println();
        }

        for(int i=a;i>=1;i--)
        {
            for(int j=1;j<=a-i;j++)
            {
                System.out.print(" ");
            }
            for(int j=1;j<=2*i-1;j++)
            {
                System.out.print("*");
            }
            System.out.println();
        }

    }
}
