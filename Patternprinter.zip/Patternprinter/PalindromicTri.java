package p14;

import java.util.*;

public class PalindromicTri
{
    int a,i,j,k;
    public void printPalinPy() 
    {
        System.out.println("Enter the no of Rows : ");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();

        System.out.println();
        for(int i=1;i<=a;i++)
        {
            for(int k=1;k<=a-i;k++)
            {
                System.out.print(" ");
            }
            for(int j=i;j>=1 ;j--)
            {
                System.out.print(j);
            }
            for(int j=2; j<=i;j++)
            {
                System.out.print(j);
            }
            System.out.println();
        }
  }
}


