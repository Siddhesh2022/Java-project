package p13;

import java.util.*;

public class NumPyramid
{
    int a,i,j,k;
    public void printNumPy() 
    {
        System.out.println("Enter the no of Rows : ");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();

        System.out.println();
        for(int i=1;i<=a;i++)
        {
            for(int k=1;k<=a-i;k++)
            {
                System.out.print(" ");
            }
            for(int j=1;j<=i ;j++)
            {
                System.out.print(+i +" ");
            }
            System.out.println();
        }
  }
}


