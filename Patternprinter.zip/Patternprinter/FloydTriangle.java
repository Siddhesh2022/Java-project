package p9;

import java.util.*;

public class FloydTriangle 
{
    int a,i,j,b;
    public void printfloydTri() 
    {
        System.out.println("Enter the no of Rows : ");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        int b=1;
        System.out.println();
        for(int i=1;i<=a;i++)
        {
            for(int j=1;j<=i;j++)
            {
                System.out.print(b++ +" ");
            }
            System.out.println();
        }
  }
}

