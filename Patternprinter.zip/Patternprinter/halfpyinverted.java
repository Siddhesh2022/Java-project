package p6;

import java.util.*;

public class halfpyinverted
{
    int a,i,j;
    public void printHalfpyinverted() 
    {
        System.out.println("Enter the no of Rows : ");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();

        System.out.println();
        for(int i=1;i<=a;i++)
        {
            for(int j=1;j<=a-i+1;j++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
  }
}
