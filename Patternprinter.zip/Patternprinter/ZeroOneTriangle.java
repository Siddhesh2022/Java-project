package p10;

import java.util.*;

public class ZeroOneTriangle  
{
    int a,i,j,b;
    public void printZeroOneTri() 
    {
        System.out.println("Enter the no of Rows : ");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        System.out.println();
        for(int i=1;i<=a;i++)
        {
            for(int j=1;j<=i;j++)
            {
                int b =i+j;
                if(b%2==0)
                {
                    System.out.print("1 ");
                }
                else
                {
                    System.out.print("0 ");
                }
            }
            System.out.println();
        }
  }
}


