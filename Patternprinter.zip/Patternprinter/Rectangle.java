package p1;

import java.util.*;

public class Rectangle
{
    int a,b,i,j;
    public void printRect() 
    {
        System.out.println("Enter the Length of the Rectangle : ");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();

        System.out.print("Enter the Breath of the Rectangle : ");
        Scanner scan1 = new Scanner(System.in);
        int b = scan1.nextInt();
        System.out.println();
        for(int i=1;i<=b;i++)
        {
            for(int j=1;j<=a;j++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
  }
}
