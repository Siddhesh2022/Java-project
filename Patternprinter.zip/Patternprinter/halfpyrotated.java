package p8;

import java.util.*;

public class halfpyrotated
{
    int a,i,j,k;
    public void printHalfpyramidrot() 
    {
        System.out.println("Enter the no of Rows : ");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();

        System.out.println();
        for(int i=1;i<=a;i++)
        {
            for(int k=1;k<i;k++)
            {
                System.out.print(" ");
            }
            for(int j=1;j<=a-i+1 ;j++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
  }
}

