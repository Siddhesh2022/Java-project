package p3;

import java.util.*;

public class hollowRect
{
    int a,b,i,j;
    public void printHollowRect() 
    {
        System.out.println("Enter the Length of the Hollow Rectangle : ");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();

        System.out.print("Enter the Breath of the Hollow Rectangle : ");
        Scanner scan1 = new Scanner(System.in);
        int b = scan1.nextInt();
        System.out.println();
        for(int i=1;i<=b;i++)
        {
            for(int j=1;j<=a;j++)
            {
                if(i==1 || j==1 || i==b || j==a)
                {
                    System.out.print("*");
                }
                else
                {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
  }
}
