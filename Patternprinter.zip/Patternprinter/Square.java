package p2;

import java.util.*;

public class Square
{
    int a,j,i;
    public void printSq() 
    {
        System.out.println("Enter the Length of the Side of Square :");
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        System.out.println();
        for(int i=1;i<=a;i++)
        {
            for(int j=1;j<=a;j++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
  }
}

